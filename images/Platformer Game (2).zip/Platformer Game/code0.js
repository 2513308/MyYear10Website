gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDplatform1Objects1= [];
gdjs.Untitled_32sceneCode.GDplatform1Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDplayerObjects1= [];
gdjs.Untitled_32sceneCode.GDplayerObjects2= [];
gdjs.Untitled_32sceneCode.GDCoinObjects1= [];
gdjs.Untitled_32sceneCode.GDCoinObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDcloud1Objects1= [];
gdjs.Untitled_32sceneCode.GDcloud1Objects2= [];
gdjs.Untitled_32sceneCode.GDcloud2Objects1= [];
gdjs.Untitled_32sceneCode.GDcloud2Objects2= [];
gdjs.Untitled_32sceneCode.GDMOOONObjects1= [];
gdjs.Untitled_32sceneCode.GDMOOONObjects2= [];
gdjs.Untitled_32sceneCode.GDred_9595boxObjects1= [];
gdjs.Untitled_32sceneCode.GDred_9595boxObjects2= [];
gdjs.Untitled_32sceneCode.GDghostObjects1= [];
gdjs.Untitled_32sceneCode.GDghostObjects2= [];
gdjs.Untitled_32sceneCode.GDplatform2Objects1= [];
gdjs.Untitled_32sceneCode.GDplatform2Objects2= [];
gdjs.Untitled_32sceneCode.GDfakeplatformObjects1= [];
gdjs.Untitled_32sceneCode.GDfakeplatformObjects2= [];
gdjs.Untitled_32sceneCode.GDSUNObjects1= [];
gdjs.Untitled_32sceneCode.GDSUNObjects2= [];
gdjs.Untitled_32sceneCode.GDorangeObjects1= [];
gdjs.Untitled_32sceneCode.GDorangeObjects2= [];
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects1= [];
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects2= [];
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects1= [];
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects2= [];
gdjs.Untitled_32sceneCode.GDbackgorundObjects1= [];
gdjs.Untitled_32sceneCode.GDbackgorundObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDplatform3Objects1= [];
gdjs.Untitled_32sceneCode.GDplatform3Objects2= [];
gdjs.Untitled_32sceneCode.GDMountain_9595Objects1= [];
gdjs.Untitled_32sceneCode.GDMountain_9595Objects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Untitled_32sceneCode.GDplayerObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.Untitled_32sceneCode.GDCoinObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Untitled_32sceneCode.GDCoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDplayerObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCoinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Untitled_32sceneCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDplayerObjects1[i].getY() > 540 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDplayerObjects1[k] = gdjs.Untitled_32sceneCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDplayerObjects1[i].setPosition(200,275);
}
}
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDplatform1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloud1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloud1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloud2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloud2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMOOONObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMOOONObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDred_9595boxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDred_9595boxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDghostObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDghostObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplatform2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDfakeplatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfakeplatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSUNObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSUNObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDorangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDorangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbackgorundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbackgorundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDplatform3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMountain_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDMountain_9595Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
gdjs.Untitled_32sceneCode.GDplatform1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDplayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloud1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloud1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDcloud2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDcloud2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMOOONObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMOOONObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDred_9595boxObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDred_9595boxObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDghostObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDghostObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDplatform2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDfakeplatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfakeplatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSUNObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSUNObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDorangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDorangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDyellowly_9595orangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDorange_9595blackObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbackgorundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbackgorundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDplatform3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDplatform3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMountain_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDMountain_9595Objects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
